import asyncio
import click
import json
import csv
from crawler import AsyncCrawler

@click.command()
@click.option('--url', required=True, help='Start URL to crawl')
@click.option('--depth', default=2, help='Max crawl depth')
@click.option('--output', default='data.json', help='Output file: data.json or data.csv')
def main(url, depth, output):
    """Async Web Crawler CLI Tool for DEV-NEXES"""
    click.echo(f"[*] Starting crawl on {url} with depth {depth}")
    crawler = AsyncCrawler(url, depth)
    data = asyncio.run(crawler.run())
    
    # Export JSON or CSV
    if output.endswith('.csv'):
        with open(output, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['url', 'title'])
            writer.writeheader()
            writer.writerows(data)
    else:
        with open(output, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    
    click.echo(f"[+] Done! Found {len(data)} pages. Saved to {output}")

if __name__ == '__main__':
    main()