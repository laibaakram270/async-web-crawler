import asyncio
import httpx
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import time

# MODULE 2: TOKEN BUCKET - Rate Limiter
class TokenBucket:
    def __init__(self, rate, capacity):
        self.rate = rate
        self.capacity = capacity
        self.tokens = capacity
        self.last_check = time.time()

    async def consume(self):
        while self.tokens < 1:
            await asyncio.sleep(0.1)
            now = time.time()
            delta = now - self.last_check
            self.tokens = min(self.capacity, self.tokens + delta * self.rate)
            self.last_check = now
        self.tokens -= 1

# MODULE 3: SIMPLE BLOOM FILTER - For duplicate URLs
class SimpleBloom:
    def __init__(self, size=1000000):
        self.size = size
        self.bit_array = bytearray(size)
    
    def _hash(self, url):
        return hash(url) % self.size
    
    def add(self, url):
        self.bit_array[self._hash(url)] = 1
    
    def __contains__(self, url):
        return self.bit_array[self._hash(url)] == 1

# MODULE 2: ROBOTS.TXT CHECKER
async def can_fetch(client, url):
    """Check robots.txt before crawling"""
    parsed = urlparse(url)
    robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
    try:
        resp = await client.get(robots_url, timeout=5)
        if resp.status_code == 200:
            # Simple check: if Disallow: / then block everything
            if "Disallow: /" in resp.text:
                return False
    except:
        pass
    return True

# MODULE 1: ASYNC CRAWLER
class AsyncCrawler:
    def __init__(self, start_url, max_depth):
        self.start_url = start_url
        self.max_depth = max_depth
        self.visited = SimpleBloom()
        self.rate_limiter = TokenBucket(rate=2, capacity=5) # 2 req/sec
        self.data = []
        self.client = httpx.AsyncClient(timeout=10.0, follow_redirects=True)

    async def fetch(self, url):
        await self.rate_limiter.consume()
        try:
            resp = await self.client.get(url)
            return resp.text
        except:
            return ""

    async def crawl(self, url, depth):
        if depth > self.max_depth or url in self.visited:
            return
        self.visited.add(url)
        
        # CHECK ROBOTS.TXT BEFORE FETCHING
        if not await can_fetch(self.client, url):
            print(f"[-] Blocked by robots.txt: {url}")
            return
        
        html = await self.fetch(url)
        if not html: return
        
        soup = BeautifulSoup(html, "html.parser")
        title = soup.title.string if soup.title else "No Title"
        self.data.append({"url": url, "title": title})
        print(f"[+] Crawled: {url}")
        
        tasks = []
        for link in soup.find_all("a", href=True):
            next_url = urljoin(url, link['href'])
            # Only crawl same domain
            if urlparse(next_url).netloc == urlparse(self.start_url).netloc:
                tasks.append(self.crawl(next_url, depth + 1))
        
        await asyncio.gather(*tasks)

    async def run(self):
        await self.crawl(self.start_url, 0)
        await self.client.aclose()
        return self.data